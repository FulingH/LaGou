const express = require('express')
const router = express.Router()

const posController = require('../controllers/position.controller')

router.get('/add', posController.save);

module.exports = router;
