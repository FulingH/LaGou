const mongoose = require('mongoose')
const PositionSchema = mongoose.Schema({
  companyName: { type: String, required: true },
  positionName: { type: String, required: true },
  city: { type: String, required: true },
  salary: { type: String, required: true },
  degree: { type: String, required: true },
  type: { type: String, required: true },
  experience: { type: String, required: true },
  description: { type: String, required: true },
  createTime: { type: Date, default: Date.now }
})

const User = mongoose.model('Positions', PositionSchema)

const save = (data) => {
  let users = new User(data)
  return users.save()
}

module.exports = {
  save
}
