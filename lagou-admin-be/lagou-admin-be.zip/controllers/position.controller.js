const posModel = require('../models/position.model')

const add = (req, res, next) => {
  console.log(req.body('username'));
}

module.exports = {
  add
}
