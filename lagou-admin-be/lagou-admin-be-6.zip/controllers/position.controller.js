const posModel = require('../models/position.model')
const moment = require('moment')
const fs = require('fs')
const path = require('path')

const save = async (req, res, next) => {
  res.setHeader('Content-Type', 'application/json; charset=utf8')
  req.body.createTime = moment().format('YYYY-MM-DD h:mm')
  req.body.companyLogo = req.filename
  const result = await posModel.save(req.body)
  if (result) {
    res.render('position', {ret: true, data: JSON.stringify({msg: 'succ'})})
  } else {
    res.render('position', {ret: false, data: JSON.stringify({msg: 'fail'})})
  }
}

const find = async (req, res, next) => {
  res.setHeader('Content-Type', 'application/json; charset=utf8')
  const result = await posModel.find()
  res.send(result)
}

const remove = async (req, res, next) => {
  res.setHeader('Content-Type', 'application/json; charset=utf8')
  const {id, filename} = req.body
  fs.unlink(path.resolve(__dirname, '../public/uploads/', filename), async (err) => {
    if (err) {
      res.send({ret: false, data: {msg: '删除失败!'}})
    }
    const result = await posModel.remove(id)
    res.send({ret: true, data: result})
  })
}

module.exports = {
  save,
  find,
  remove
}
