const express = require('express')
const router = express.Router()

const posController = require('../controllers/position.controller')

const fileuploadMiddleware = require('../middlewares/fileupload')

router.route('/save')
  .post(fileuploadMiddleware.fileupload, posController.save)

router.route('/find')
  .get(posController.find)

module.exports = router
