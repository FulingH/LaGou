const posModel = require('../models/position.model')

const save = async (req, res, next) => {
  res.setHeader('Content-Type', 'application/json; charset=utf8')
  const result = await posModel.save(req.body)
  if (result) {
    res.render('position', {ret: true, data: JSON.stringify({msg: 'succ'})})
  } else {
    res.render('position', {ret: false, data: JSON.stringify({msg: 'fail'})})
  }
}

const find = async (req, res, next) => {
  res.setHeader('Content-Type', 'application/json; charset=utf8')
  const result = await posModel.find()
  res.send(result)
}

module.exports = {
  save,
  find
}
