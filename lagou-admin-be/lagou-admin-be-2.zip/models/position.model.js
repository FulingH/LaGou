const db = require('../utils/mongo.util')

const PositionSchema = db.Schema({
  companyName: { type: String, required: true },
  positionName: { type: String, required: true },
  city: { type: String, required: true },
  salary: { type: String, required: true },
  degree: { type: String, required: true },
  type: { type: String, required: true },
  experience: { type: String, required: true },
  description: { type: String, required: true },
  createTime: { type: Date, default: Date.now}
})

const Position = db.model('Positions', PositionSchema)

const save = (data) => {
  let pos = new Position(data)
  return pos.save().then((result) => {
    return result
  }).catch((err) => {
    return false
  })
}

const find = () => {
  return Position.find({}).then(result => result)
}

module.exports = {
  save,
  find
}
