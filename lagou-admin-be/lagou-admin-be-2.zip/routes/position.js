const express = require('express')
const router = express.Router()

const posController = require('../controllers/position.controller')

router.route('/save')
  .post(posController.save)

router.route('/find')
  .get(posController.find)

module.exports = router
