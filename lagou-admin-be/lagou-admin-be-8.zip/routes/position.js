const express = require('express')
const router = express.Router()

const posController = require('../controllers/position.controller')

const fileuploadMiddleware = require('../middlewares/fileupload')

router.route('/position')
  .post(fileuploadMiddleware.fileupload, posController.save)
  // .get(posController.findAll)
  .get(posController.find)
  .delete(posController.remove)

router.route('/position/:id')
  .get(posController.findById)

router.route('/position/update')
  .post(fileuploadMiddleware.fileupload, posController.update)

module.exports = router
