const express = require('express')
const router = express.Router()

const posController = require('../controllers/position.controller')

const fileuploadMiddleware = require('../middlewares/fileupload')

router.route('/position')
  .post(fileuploadMiddleware.fileupload, posController.save)
  .get(posController.findAll)
  .delete(posController.remove)

router.route('/position/:id')
  .get(posController.findById)

module.exports = router
