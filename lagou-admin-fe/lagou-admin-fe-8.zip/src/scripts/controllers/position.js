// 引入三个view
const positionListTpl = require('../views/position.list.html')
const positionAddTpl = require('../views/position.add.html')
const positionUpdateTpl = require('../views/position.update.html')

const positionModel = require('../models/position')

// 定义position Controller (单例)
const positionController = {
  // 职位list列表接口
  async listPos({res, req, router}){
    positionController._renderList({res, req, router})
  },

  _getPosList: ({start, count}) => {
    return $.ajax({
      url: '/api/position',
      type: 'get',
      success: (result) => {
        return result
      }
    })
  },

  async _renderList({res, req, router}) {
    let { start, count } = req.query || { start: 0, count: 10 }
    console.log(start);
    let that = positionController
    let result = await that._getPosList({start, count})
    let tpl = template.render(positionListTpl, {data: result.data.result})
    res.render(tpl)

    $('#addbtn').on('click', () => {
      router.go('/position_save')
    })
    that.removePos({res, router})
    that._updatePosInit({router})
  },

  // 职位添加接口
  addPos({res, req ,router}) {
    let that = positionController
    res.render(positionAddTpl)
    $('#posback').on('click', () => {
      router.back()
    })
    that._handleSubmit(router)
  },

  _handleSubmit(router) {
    let that = positionController
    $('#possubmit').on('click', async () => {
      var options = {
        "success" : (result, status) => {
          that._resultForm(result, status, router)
        },
        "resetForm" : true,
        "dataType" : "json"
      };
      $("#possave").ajaxSubmit(options)
    })
  },

  _resultForm(result, status, router) {
    if (result.ret) {
      router.back()
    } else {
      alert('数据修改错误~')
    }
  },

  // 职位删除接口
  removePos({res, router}) {
    let that = positionController
    $('.pos-remove').on('click', async function () {
      let id = $(this).attr('posid')
      let filename = $(this).attr('filename')
      if (window.confirm('真的要删除吗')) {
        await positionModel.remove(id, filename)
        that._renderList({res, router})
      }
    })
  },

  // 修改职位信息初始化
  _updatePosInit({router}) {
    // 在list加载完的时候绑定
    $('.pos-edit').on('click', function () {
      let id = $(this).attr('posid')
      router.go('/position_update', { id })
    })
  },

  // 职位修改接口（点击修改按钮的时候触发）
  async updatePos({res, req, router}) {
    let that = positionController
    let result = await positionModel.findById(req.body.id)
    let tpl = template.render(positionUpdateTpl, {data: result.data})
    router.render(tpl)

    that._handleSubmit(router)

    $('#posback').on('click', () => {
      router.back()
    })
  }

}

const { addPos, listPos, updatePos } = positionController

module.exports = {
  addPos, listPos, updatePos
}
