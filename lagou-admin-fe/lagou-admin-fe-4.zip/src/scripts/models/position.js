const list = (data) => {
  return $.ajax({
    url: '/api/position/save',
    type: 'POST',
    data,
    success: (result) => {
      return result
    }
  })
}

module.exports = {
  list
}
