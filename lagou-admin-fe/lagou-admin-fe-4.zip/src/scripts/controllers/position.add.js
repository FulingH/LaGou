const positionAddTpl = require('../views/position.add.html')
const positionModel = require('../models/position')

module.exports = {
  render({res, req ,router}) {
    res.render(positionAddTpl)
    $('#addback').on('click', () => {
      router.back()
    })
    this.handleSubmit(router)
  },

  handleSubmit(router) {
    $('#addsubmit').on('click', async () => {
      var options = {
        "success" : (result, status) => {
          this.resultForm(result, status, router)
        },
        "resetForm" : true,
        "dataType" : "json"
      };
      $("#possave").ajaxSubmit(options)
      
      // let companyName = $('#companyName').val(),
      // positionName = $('#positionName').val(),
      // city = $('#city').val(),
      // salary = $('#salary').val(),
      // degree = $('#degree').val(),
      // type = $('#type').val(),
      // experience = $('#experience').val(),
      // description = $('#description').val()
      //
      // const result = await positionModel.list({
      //   companyName,
      //   positionName,
      //   city,
      //   salary,
      //   degree,
      //   type,
      //   experience,
      //   description
      // })
      //
      // if (result.ret) {
      //   router.back()
      // }
    })
  },

  resultForm(result, status, router) {
    if (result.ret) {
      router.back()
    }
  }
}
