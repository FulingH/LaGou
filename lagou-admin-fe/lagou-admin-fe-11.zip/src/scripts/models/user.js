const signin = (data) => {
  return $.ajax({
    url: '/api/users/signin',
    type: 'post',
    data,
    success: (result) => {
      return result
    }
  })
}

module.exports = {
  signin
}
