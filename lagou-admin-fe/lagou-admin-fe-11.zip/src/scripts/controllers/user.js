const headerTpl = require('../views/header.html')
const userModel = require('../models/user')

var wsCache = new WebStorageCache();

module.exports = {
  async render() {
    let html = template.render(headerTpl, {
      greeting: '',
      isSignin: false
    })
    $('.wrapper').prepend(html)
    $('#user-submit').on('click', async() => {
      let {username, password} = {
        username: $('#username').val(),
        password: $('#password').val()
      }
      let result = await userModel.signin({username, password})
      if (result.ret) {
        // 将token保存到localstorage里
        wsCache.set('token', result.data.token)
        // 重新渲染模板
        let html = template.render(headerTpl, {
          greeting: '你好，' + result.data.username,
          isSignin: true
        })
        $('.wrapper').find('.main-header').remove()
        $('.wrapper').prepend(html)
      }
    })
  }
}
