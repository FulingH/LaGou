const positionAddTpl = require('../views/position.add.html')

module.exports = {
  render({res, router}) {
    res.render(positionAddTpl)
    $('#addback').on('click', () => {
      router.back()
    })
    this.handleSubmit(router)
  },

  handleSubmit(router) {
    $('#addsubmit').on('click', () => {
      let companyName = $('#companyName').val(),
          positionName = $('#positionName').val(),
          city = $('#city').val(),
          salary = $('#salary').val(),
          degree = $('#degree').val(),
          type = $('#type').val(),
          experience = $('#experience').val(),
          description = $('#description').val()

      $.ajax({
        url: '/api/position/save',
        type: 'POST',
        data: {
          companyName,
          positionName,
          city,
          salary,
          degree,
          type,
          experience,
          description
        },
        success: (result) => {
          this.handleSubmitSucc(result, router)
        }
      })
    })
  },

  handleSubmitSucc(result, router) {
    if (result.ret) {
      router.back()
    }
  }
}
