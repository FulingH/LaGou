const positionTpl = require('../views/position.html')

module.exports = {
  async render({res, router}){
    let result = await this.getPosList()
    let tpl = template.render(positionTpl, {data: result})
    res.render(tpl)
    $('#addbtn').on('click', () => {
      router.go('/position/save')
    })
  },

  getPosList: () => {
    return $.ajax({
      url: '/api/position/find',
      success: (result) => {
        return result
      }
    })
  }
}
