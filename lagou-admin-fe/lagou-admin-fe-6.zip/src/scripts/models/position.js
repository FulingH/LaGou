const list = (data) => {
  return $.ajax({
    url: '/api/position',
    type: 'POST',
    data,
    success: (result) => {
      return result
    }
  })
}

const remove = (id, filename) => {
  return $.ajax({
    url: '/api/position',
    type: 'delete',
    data: {
      id,
      filename
    },
    success: (result) => {
      if (result.ret) {
        return result
      }
    }
  })
}

module.exports = {
  list,
  remove
}
