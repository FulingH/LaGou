import SMERouter from 'sme-router'
const positionTpl = require('../views/position.html')
const homeTpl = require('../views/home.html')
const router = new SMERouter('router-view')

// route config
router.route('/position', (req, res, next) => {
  res.render(positionTpl)
})

router.route('/home', (req, res, next) => {
  res.render(homeTpl)
})

router.route('*', (req, res, next) => {
  res.redirect('/home')
})
