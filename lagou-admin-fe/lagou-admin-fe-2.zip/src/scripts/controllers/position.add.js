const positionAddTpl = require('../views/position.add.html')

module.exports = {
  render({res, router}) {
    res.render(positionAddTpl)
    $('#addback').on('click', () => {
      router.back()
    })
    this.doSubmit()
  },

  doSubmit() {
    $('#addsubmit').on('click', () => {
      let companyName = $('#companyName').val(),
          positionName = $('#positionName').val(),
          city = $('#city').val(),
          salary = $('#salary').val(),
          degree = $('#degree').val(),
          experience = $('#experience').val(),
          description = $('#description').val()

      $.ajax({
        url: '/api/position/add',
        type: 'POST',
        data: {
          companyName,
          positionName,
          city,
          salary,
          degree,
          experience,
          description
        },
        success(result) {
          console.log(result)
        }
      })
    })
  }
}
