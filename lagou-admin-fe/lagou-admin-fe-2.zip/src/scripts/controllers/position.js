const positionTpl = require('../views/position.html')

module.exports = {
  render({res, router}){
    res.render(positionTpl)
    $('#addbtn').on('click', () => {
      router.go('/position/add')
    })
  }
}
